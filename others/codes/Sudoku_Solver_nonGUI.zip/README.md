# Sudoku_Solver_nonGUI
This program can solve a sudoku for you easily

Just edit the board in main.py and run it
