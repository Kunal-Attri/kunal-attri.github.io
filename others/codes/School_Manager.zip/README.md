# School-Manager
This program stores and handles the data about students and teachers working in a school
