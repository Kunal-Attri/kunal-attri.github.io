from get_data import *

students, sage, standard, teachers, tage, subject = update_data()
