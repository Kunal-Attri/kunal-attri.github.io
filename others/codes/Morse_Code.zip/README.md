# Morse_Code
This code will help you convert any English sentence into morse codes. Just type in the sentence and press enter, and you rae done!
