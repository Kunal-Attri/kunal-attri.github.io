# Sudoku_Solver_GUI
This is a graphical form of sudoku solver of the previous non-GUI version

Just edit the board in main.py and run the program

Instructions:

1. Use spacebar if u want the computer to solve the program

2. Use mouse or arrow keys to navigate on the board

3. Tye a no in a box for refence and press enter to put it there
