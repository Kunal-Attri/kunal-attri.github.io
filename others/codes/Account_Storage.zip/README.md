# Account-Storage
This project is aimed to store all your accounts ID and passwords securely on your computer.
1) Default Password = tim
2) To change password, open Change_password.py, enter default password and change the password.


DO NOT DELETE ids.txt that will delete all your stored account ids and passwords 
